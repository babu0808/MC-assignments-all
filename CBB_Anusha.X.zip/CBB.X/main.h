#ifndef MAIN_H
#define MAIN_H


#define DASHBOARD_SCREEN 0x01 
#define LOGIN_SCREEN     0x02
#define MENU_SCREEN      0x03

#define RESET_PASSWORD   0x0A
#define RESET_NOTHING    0x0B

#define RETURN_BACK      0xA0
#define LOGIN_SUCCESS    0xB0

#define RESET_LOGIN_MENU       0x0C
#define CURSOR_POSITION  0xC6        

#include <xc.h>
#include "digital_keypad.h"
#include "clcd.h"
#include "adc.h"
#include "i2c.h"
#include "ds1307.h"
#include "c_b_b.h"
#include <string.h>
#include "at24c04.h"
#include"timer2.h"

#endif