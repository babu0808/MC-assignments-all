
/*------------------------------------------------------------------------------------------------- 
 *   Author         : Babu Malagaveli 
 *   Date           : Wed 11 Oct 2023 16:00:04 IST
 *   File           : isr.c
 *   Title          : Interrupt Service Routine
 *   Description    : Signal registration happens here
 *-----------------------------------------------------------------------------------------------*/
#include<xc.h>
#include"main.h"

//extern unsigned char count;
extern unsigned char sec, return_time;

void __interrupt() isr(void) {
    static unsigned int count = 0;

    if (TMR0IF == 1) //If the Timer0 Overflow Interrupt Flag Bit is set, Timer0 is requesting for an Interrupt.
    {

        if (count++ == 1250) //The formula for the Timer0 yields the result as: 0.5 sec for every 10000 ticks.
        {
            count = 0;
            if (sec > 0) {
                sec--;
            }
            if (sec == 0 && return_time > 0) {
                return_time--;
            }
        }

        TMR0IF = 0; //To clear the Timer0 Overflow Interrupt Flag Bit to avoid Recursive interrupts.
    }
}
