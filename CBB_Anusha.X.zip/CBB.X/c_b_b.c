
#include "main.h"
unsigned char time[9]; // "HH:MM:SS"
char clock_reg[3];
unsigned char log[10];
char pos = -11;
char event;
unsigned char sec = 60;
unsigned char return_time = 5;
unsigned char first = 0; //Holds first index value of an event
unsigned char last = 0; //Holds last index value of an event

void clear_screen() {
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE); //0x01 1
    __delay_us(100); //100 usec 
}

static void get_time() {

    clock_reg[0] = read_ds1307(HOUR_ADDR); // HH -> BCD 
    clock_reg[1] = read_ds1307(MIN_ADDR); // MM -> BCD 
    clock_reg[2] = read_ds1307(SEC_ADDR); // SS -> BCD 


    // HH -> 
    time[0] = ((clock_reg[0] >> 4) & 0x03) + '0';
    time[1] = (clock_reg[0] & 0x0F) + '0';

    time[2] = ':';
    // MM 
    time[3] = ((clock_reg[1] >> 4) & 0x07) + '0';
    time[4] = (clock_reg[1] & 0x0F) + '0';

    time[5] = ':';
    // SS
    time[6] = ((clock_reg[2] >> 4) & 0x07) + '0';
    time[7] = (clock_reg[2] & 0x0F) + '0';
    time[8] = '\0';
}

void display_dashboard(char *event, char speed) {
    clcd_print("  TIME  E  SP", LINE1(0));
    get_time();
    clcd_print(time, LINE2(2));
    clcd_print(event, LINE2(11));

    if (strcmp(event, "ON") == 0) {
        speed = 0;
    }
    clcd_putch(((speed / 10) + '0'), LINE2(14));
    clcd_putch(((speed % 10) + '0'), LINE2(15));

    /*save log */

}

void log_event_to_external_eeprom() {

    char address = 0x05;
    pos++;
    if (pos == 10) {
        pos = 0;
    }
    address = pos * 10 + 5; /*5 15 25 30 35*/
    if (event < 9) {
        event++;
    }
    eeprom_at24c04_str_write(address, log);

}

void log_event(char *event, char speed) {
    //    log[] = HHMMSSEVSP \0 -> 11 characters
    get_time();
    log[0] = time[0];
    log[1] = time[1];
    log[2] = time[3];
    log[3] = time[4];
    log[4] = time[6];
    log[5] = time[7];

    //copy two chars of event
    strncpy(&log[6], event, 2);
    log[8] = (speed / 10) + '0';
    log[9 ] = (speed % 10) + '0';
    log[10] = '\0';

    log_event_to_external_eeprom();
}

unsigned char login_screen(char reset_flag, unsigned char key) {
    static int attempts = 3;
    char spassword[4], upassword[4];
    int i = 0;
    if (reset_flag == RESET_PASSWORD) {
        attempts = 3;
        upassword[0] = '\0';
        upassword[1] = '\0';
        upassword[2] = '\0';
        upassword[3] = '\0';
        i = 0;
        key = 0xFF; //ALL_RELEASED
        return_time = 5;
    }
    if (key == SW4 && i < 4) {
        upassword[i] = '0';
        clcd_putch('*', LINE2(CURSOR_POSITION + i)); // or try 6+i
        i++;
    } else if (key == SW5 && i < 4) {
        upassword[i] = '1';
        clcd_putch('*', LINE2(CURSOR_POSITION + i));
        i++;
        return_time = 5;
    }
    if (return_time == 0) {
        //go to default screen
        return RETURN_BACK;
    }
    if (i == 4) { /*user is done entering the password*/
        //take the system password
        //compare it with user entered password
        for (char j = 0; j < 4; j++) {
            spassword[j] = eeprom_at24c04_random_read(j);
        }
        if (strncmp(spassword, upassword, 4) == 0) //compare only the first 4 characters
        {
            return LOGIN_SUCCESS; //goto the next screen->menu screen
        } else {
            attempts--; //reduce the no. off attempts
            if (attempts == 0) {
                //lock he user for 15 minutes
                sec = 60;
                clear_screen();
                clcd_print("You are locked ", LINE1(0));
                clcd_print("Wait for...60 sec", LINE2(0));
                while (sec) {
                    clcd_putch(sec / 10 + '0', LINE1(11));
                    clcd_putch((sec % 10 + '0'), LINE2(12));
                }
            } else {
                clear_screen();
                clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                clcd_print("Wrong password", LINE1(0));
                clcd_putch(attempts + '0', LINE2(0));
                clcd_print("Attempts left", LINE2(1));
                __delay_ms(4000);
            }
            clear_screen();
            clcd_print("ENTER PASSWORD ", LINE1(0));
            clcd_write(CURSOR_POSITION, INST_MODE); //blink at 6th position at every half second
            __delay_us(100);
            clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
            __delay_us(100);
            i = 0;
            return_time = 5;
        }
    }
    return 0XFF;
}

unsigned char display_menu(unsigned char key, unsigned char reset_flag) {
    char *menu[] = {"View log", "clear_log", "Download_log", "change Password", "set time"};
    static char menu_pos;
    if (reset_flag == RESET_LOGIN_MENU) {
        menu_pos = 0;
        clear_screen();
    }
    if (key == SW5 && menu_pos <= 3) {
        menu_pos++;
        clear_screen();

    } else if (key == SW4 && menu_pos > 0) {
        menu_pos--;
        clear_screen();
    }
    if (menu_pos < 4) {
        clcd_putch('*', LINE1(0));
        clcd_print(menu[menu_pos], LINE1(2));
        clcd_print(menu[menu_pos + 1], LINE2(2));
    } else if (menu_pos == 4) {
        clcd_print(menu[menu_pos - 1], LINE1(2));
        clcd_print(menu[menu_pos ], LINE2(2));
        clcd_putch('*', LINE2(0));

    }
    return menu_pos;
}

void display_view_log(char menu_pos) {
    clcd_print("# TIME     E  SP", LINE1(0));
    //menu_pos in the range from 0 to MAX_LOG_COUNT - 1
    (menu_pos >= first) ? clcd_putch('0' + menu_pos - first, LINE2(0)) : clcd_putch('0' + menu_pos + MAX_LOG_COUNT - first, LINE2(0));
    //Display time values
    clcd_putch(log[0], LINE2(2));
    clcd_putch(log[1], LINE2(3));
    clcd_putch(':', LINE2(4));
    clcd_putch(log[2], LINE2(5));
    clcd_putch(log[3], LINE2(6));
    clcd_putch(':', LINE2(7));
    clcd_putch(log[4], LINE2(8));
    clcd_putch(log[5], LINE2(9));
    //Display event & speed values
//    display_event(log[6]);
//    itoa_display(log[7]);
}
