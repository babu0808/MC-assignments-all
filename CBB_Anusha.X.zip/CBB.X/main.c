/*
 * File:   main.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on October 20, 2023, 10:30 PM
 */


#include "main.h"

#pragma config WDTE = OFF //Watchdog timer disabled

static void init_config(void) {
    //Write your initialization code here
    init_digital_keypad();
    init_clcd();
    init_adc();
    init_ds1307();
    init_i2c(100000);
    init_timer();
    GIE = 1;
    PEIE = 1;
}

void main(void) {
    init_config(); //Calling initializing function
    unsigned char control_flag = DASHBOARD_SCREEN; /*represents dashboard*/
    char event[3] = "ON";
    char speed = 0, gr = 0;
    unsigned char key;
    unsigned char reset_flag = RESET_PASSWORD;
    eeprom_at24c04_str_write(0x00, "1010"); //system password for device
    log_event(event, speed);
    char *gear[] = {"GN", "G1", "G2", "G3", "G4", "GR"};

    while (1) {
        //Write application code here
        speed = (read_adc() / 10);
        key = read_digital_keypad(STATE);
        for (unsigned int i = 0; i++ < 3000;); /*delay to avoid boundcing effect*/

        if (speed > 99) {
            speed = 99;
        }
        if (key == SW1) {
            //event is collision
            strcpy(event, "C ");

            log_event(event, speed);
        } else if (key == SW2 && gr < 6) {
            /*upgearing*/
            strcpy(event, gear[gr]);
            gr++;
            log_event(event, speed);

        } else if (key == SW3 && gr > 0) {
            /*downgearing*/
            strcpy(event, gear[gr]);
            gr--;
            log_event(event, speed);

        } else if ((key == SW4 | key == SW5) && control_flag == DASHBOARD_SCREEN) { //confirmation that we are in dashboard screen
            control_flag = LOGIN_SCREEN;
            clear_screen();
            clcd_print("ENTER PASSWORD ", LINE1(0));
            clcd_write(CURSOR_POSITION, INST_MODE); //blink at 6th position at every half second
            __delay_us(100);
            clcd_write(DISP_ON_AND_CURSOR_ON, INST_MODE);
            __delay_us(100);
            reset_flag = RESET_PASSWORD;
            TMR2ON = 1;
        }
        switch (control_flag) {
            case 0x01: /*default screen*/
                display_dashboard(event, speed);
                break;
            case 0x02: /*login screen*/
                switch (login_screen(reset_flag, key)) {
                    case RETURN_BACK:
                        control_flag = DASHBOARD_SCREEN;
                        TMR2ON = 0;
                        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                        break;
                    case LOGIN_SUCCESS:
                        control_flag = MENU_SCREEN;
                        reset_flag = RESET_LOGIN_MENU;
                        TMR2ON = 0;
                        clcd_write(DISP_ON_AND_CURSOR_OFF, INST_MODE);
                        continue;
                        break;
                }
                break;
            case 0x03: /*menu screen*/
                switch (display_menu(key, reset_flag)) {
                        //5 sub screens    
                        //enter to the particular screen when the long press of up key happens
                        //  char *menu[] = {"View log", "clear_log", "Download_log", "change Password", "set time"};
                    case 0: //based on the menu_pos as display_menu returns menu_pos
                        //view log
//                        display_view_log(char menu_pos);
                        break;
                    case 1:
                        //clear log
                        //do not delete the data, write the data from the address from 160
                        break;
                    case 2:
                        //download log
                        //take the data from ext eeprom, store it in MC and display that on cutecom using UART
                        break;
                    case 3:
                        //change system password
                        break;
                    case 4:
                        //set log
                        break;
                }
        }
    }
    reset_flag = RESET_NOTHING;
}
