#ifndef C_B_B_H

#define C_B_B_H
void display_dashboard(char *event, char speed);
void log_event(char *event, char speed);
void clear_screen(void);
unsigned char login_screen(char reset_flag, unsigned char key);
unsigned char display_menu(unsigned char key, unsigned char reset_flag);
void display_view_log(char menu_pos);

#endif