
#include <xc.h>
#include "main.h"

unsigned char pos = 1;		//To store the Direction of the Activity.
unsigned int wait = 1;		//To store the Delay Timer.
unsigned char bias = 8;		//To store the Position of LED for the direction of Right to Left.

static void init_config (void)
{
	ADCON1 = 0X0F;				//To make the pins as Digital I/O.
	TRISB = 0X00;				//To make the PORTB as an Output port.
	LED_ARRAY = 0X00;			//To turn OFF the LEDs when the Power is ON.
	TRISB = TRISB | 0x3F;		//To make the PORTD as an Input port.
    TRISD = 0x00;
}

void main()
{
	init_config ();             //To initialize the ports and registers with the default values.

	unsigned char opt = 1, flag;

	while (1)
	{
		flag = key_press ();	//To read the Digital key Press.

		if (flag != 0)			//If the Key is pressed, the previous Pattern shall be updated with the new Pattern.
		{
			opt = flag;
		}

		if (opt == 1)			//If the SW1 is pressed, the Pattern-1 shall be executed.
		{
			led_train ();
		}
		else if (opt == 2)		//If the SW2 is pressed, the Pattern-2 shall be executed.
		{
			led_L_to_R ();
		}
		else if (opt == 3)		//If the SW3 is pressed, the Pattern-3 shall be executed.
		{
			led_alternate ();
		}
		else if (opt == 4)		//If the SW4 is pressed, the Pattern-4 shall be executed.
		{
			led_nibble ();
		}
	}
}
