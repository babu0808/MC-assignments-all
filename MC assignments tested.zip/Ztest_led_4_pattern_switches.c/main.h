#ifndef MAIN_H
#define MAIN_H

/* Macro for the PORTS */
#define LED_ARRAY 		PORTD
#define KEY_PORT 		TRISB
#define SWITCH1 		0X3F
#define SWITCH2 		0x3E
#define SWITCH3 		0x3D
#define SWITCH4 		0X3B

#define ALL_RELEASED 	0X3F

/* Function calls for the Patterns */
unsigned char key_press (void);
void led_train (void);
void led_L_to_R (void);
void led_alternate (void);
void led_nibble (void);

#endif
