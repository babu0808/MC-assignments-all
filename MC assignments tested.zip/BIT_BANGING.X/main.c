/*
 * File:   main.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on September 23, 2023, 9:47 AM
 */


#include <xc.h>
#include "main.h"
#pragma config WDTE = OFF //Watchdog timer disabled

static void init_config(void) {
    //Write your initialization code here
    LED_ARRAY = 0x00;
    LED_ARRAY_DDR = 0x00;
}

void main(void) {
    init_config(); //Calling initializing function
    unsigned long int duty_cycle = 50000, period = 100000, loop_counter;

    //for a period of 100, 50% is ON and HIGH

    while (1) {
        if (loop_counter < duty_cycle) //for 50000 iteration writing 1 
        {
            RD0 = 1;
        } else if (loop_counter < period) { //for every 100000 iteration writing 0
            RD0 = 0;
        }

        if (loop_counter++ == period) //reset it back to 0
        {
            loop_counter = 0;
        }
    }
    //Write application code here


}
