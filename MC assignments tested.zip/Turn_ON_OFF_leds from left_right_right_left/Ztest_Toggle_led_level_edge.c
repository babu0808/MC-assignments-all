/*
 * File:   Ztest.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on September 16, 2023, 11:38 AM
 */


#include <xc.h>
//
#pragma config WDTE = OFF //Watchdog timer disabled
#define LED_ARRAY_DDR TRISB
#define LED_ARRAY PORTB

static void init_config(void) {
    //Write your initialization code here
    /*
     Data direction register: it is represented by TRISx State 
    Registers . the three states are Input, output and High Impedence.
     */
    LED_ARRAY_DDR = 0x00; //set the direction of PORTB to OUTPUT
    LED_ARRAY = 0x00;       //set the initial values of LEDs to OFF state
}

void main(void) {
    init_config(); //Calling initializing function
    unsigned long int wait = 0;
    char j = 0;
    while (1) {
        if (j < 8) {                                //check if the leds are operated just 8 times
            if (++wait == 50000) {
                wait = 0;
                LED_ARRAY = (LED_ARRAY << 1) | 1;    //turn on the leds one by one
                j++;
            }
        } else if (j < 16) {                        //again operate on LEDs 8 times
            if (++wait == 50000) { //Non Blocking statement
                wait = 0;
                LED_ARRAY = (LED_ARRAY << 1);       //turn off the leds one by one 
                j++;
            }
        }
        else {
            j = 0;                                  //loop the above conditions within  and 15
        }

    }

}