/*
 * File:   main.c
 */

#include <xc.h>
#include "clcd.h"
#include "matrix_keypad.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

//Matrix  Keypad 
//key 01 pressed

void display(unsigned char key) {
    if (key != ALL_RELEASED) {
        // key 1 pressed
        clcd_print("Key  ", LINE2(0)); // Key 

        switch (key) //'*' '#' 
        {
            case '*':
            case '#':
                clcd_putch(key, LINE2(5)); //* #
                break;
            default: // 0 1 2 3 .. 9
                clcd_putch(key + '0', LINE2(5)); // 1 + '0' -> '1'
        }

        clcd_print("   Pressed", LINE2(6));
    } else {
        clcd_print(" No Key Pressed ", LINE2(0));
    }
}

static void init_config(void) {
    init_clcd();
    init_matrix_keypad();

    clcd_print(" Matrix  Keypad ", LINE1(0));
}

void main(void) {
    init_config();
    unsigned char key, pre_key;
//    clcd_print(" Select MKP SW ", LINE1(0));
//    clcd_print("S1:Right S2:Left", LINE2(0));
    char temp,temp1, i;
//    char msg[] = "CLCD_Demo_Code_0";
    char msg[] = "_GOOD MORNING_EMERTXE";
    while (1) {
//        key = read_matrix_keypad(STATE); // 0 1 2 3 4 5 6 7 8 9 '*' '#'  ALL_RELEASED
//        //        display(key);
//        if (key != ALL_RELEASED) {
//            pre_key = key;
//        }
//        if (pre_key == 1) {
            clcd_print("Right Scrolling", LINE1(0));
            temp = msg[15];
            for (int i = 15; i > 0; i--) {
                msg[i] = msg[i - 1];
            }
            msg[0] = temp;
            clcd_print(msg, LINE2(0));
//        } 
//        else if (pre_key == 2) {
//            clcd_print("Left Scrolling", LINE1(0));
//            temp1 = msg[15];
//            for (int i = 0; i < 16; i++) {
//                msg[i+1] = msg[i];
//            }
//            msg[0] = temp1;
//            clcd_print(msg, LINE2(0));
//        }
    }
    return;
}

// Matrix keypad
// No Key Pressed