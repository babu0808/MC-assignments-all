/*
 * File:   newmain.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on September 16, 2023, 3:27 PM
 */


#include <xc.h>

#pragma config WDTE = OFF //Watchdog timer disabled

static void init_config(void) {
    //Write your initialization code here
    TRISD = 0; //led at RD0 -
//    TRISB0 = 1; //uisng only one switch , setting as input 
    PORTD = 0x00; //initially leds are off
}

void main(void) {
    init_config(); //Calling initializing function
    while (1) {
        //Write application code here
        init_config();
        while (1) {
            if (RB0 == 0) //checking switch press
            {
                RD0 = !RD0; //toggle as long as the switch is pressed
                for (unsigned long int i = 50000; i--;);
            }
        }
    }

}
