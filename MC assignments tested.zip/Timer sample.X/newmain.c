/*
 * File:   newmain.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on September 21, 2023, 10:59 AM
 */


#include <xc.h>

#pragma config WDTE = OFF //Watchdog timer disabled

//static void init_config(void) {
//    //Write your initialization code here
//}
//
//void main(void) {
//    init_config(); //Calling initializing function
//    while (1) {
//        //Write application code here
//    }
//
//}

//#include <pic16f877a.h>

// Configuration settings (adjust to your hardware and oscillator configuration)
//__CONFIG(FOSC_HS & WDTE_OFF & PWRTE_ON & CP_OFF);

// Global variables
volatile unsigned int timer0_counter = 0;
volatile unsigned int timer1_counter = 0;
volatile unsigned char synchronize_flag = 0;

// Interrupt service routine for Timer 0
void interrupt ISR(void) {
    if (T0IF) {
        // Toggle LED for Timer 0
        RB0 = !RB0;

        // Reset Timer 0 counter
        TMR0 = 131; // For a 500 ms delay with a 4 MHz oscillator

        // Increment Timer 1 counter
        timer0_counter++;

        // Check if we need to synchronize
        if (timer0_counter >= 2) {
            synchronize_flag = 1;
            timer0_counter = 0;
        }

        // Clear Timer 0 interrupt flag
        T0IF = 0;
    }

    if (TMR1IF) {
        // Toggle LED for Timer 1
        RB1 = !RB1;

        // Reset Timer 1 counter
        TMR1 = 3036; // For a 500 ms delay with a 4 MHz oscillator

        // Clear Timer 1 interrupt flag
        TMR1IF = 0;
    }
}

void main() {
    // Initialize GPIO
    TRISB0 = 0; // RB0 as output for Timer 0 LED
    TRISB1 = 0; // RB1 as output for Timer 1 LED

    // Initialize Timer 0
    T0CS = 0;   // Use internal clock (Fosc/4)
    PSA = 0;    // Assign prescaler to Timer 0
    PS2 = 1;    // Prescaler 1:128
    PS1 = 1;
    PS0 = 1;
    TMR0 = 131; // For a 500 ms delay with a 4 MHz oscillator

    // Enable Timer 0 interrupt
    T0IE = 1;
    GIE = 1; // Enable global interrupt

    // Initialize Timer 1
    TMR1CS = 0; // Use internal clock (Fosc/4)
    T1CKPS1 = 1; // Prescaler 1:8
    T1CKPS0 = 1;
    TMR1 = 3036; // For a 500 ms delay with a 4 MHz oscillator

    // Enable Timer 1 interrupt
    TMR1IE = 1;

    // Enable Timer 2 (for synchronization)
    T2CON = 0x00; // Timer 2 is disabled

    // Main loop
    while (1) {
        if (synchronize_flag) {
            synchronize_flag = 0;
            
            // Synchronize Timer 2 with Timer 0 and Timer 1
            TMR2 = 0;
            TMR2ON = 1; // Start Timer 2
            
            while (TMR2IF == 0); // Wait for Timer 2 overflow
            TMR2IF = 0; // Clear Timer 2 interrupt flag
            TMR2ON = 0; // Stop Timer 2
        }
    }
}
