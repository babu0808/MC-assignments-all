/*
 * File:   Toggle_led_any_switch.c
 * Author: %<%Babu Malagaveli%>%
 *
 * Created on September 16, 2023, 4:19 PM
 */

//status : Not working 

#include <xc.h>

#pragma config WDTE = OFF //Watchdog timer disabled

void init_digital_keypad() {
    TRISB = TRISB | 0x3F; //set the direction of all switches initially all are unpressed 
}

static void init_config(void) {
    //Write your initialization code here
    TRISD = 0; //direction of D Leds output
    PORTD = 0x00; //make all D0-D7 as off initially
    init_digital_keypad();
    TRISB = 1; //switch treated as input RB0
}

unsigned char read_digital_keypad() {
    return PORTB & 0x3F; //return the switch pressed value       
}

void main(void) {
    init_config(); //Calling initializing function
    char key;
    while (1) {
        key = read_digital_keypad();
        if (key == 0x3E) //check if the sw1(RB0) is pressed
        {
            RD0 = !RD0;
        }
        //Write application code here
    }

}
