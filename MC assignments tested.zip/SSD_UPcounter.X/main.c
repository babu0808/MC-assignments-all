/*
 * File:   main.c
 */

#include <xc.h>
#include "ssd.h"

#pragma config WDTE = OFF        // Watchdog Timer Enable bit (WDT disabled)

static void init_config(void) {
    init_ssd();
}

void main(void) {
//        unsigned char ssd[MAX_SSD_CNT] = {ZERO, ZERO, ZERO, ZERO};
    unsigned char ssd[MAX_SSD_CNT];
    int count = 0, wait = 100;
    char digit[10] = {ONE, TWO, THREE, FOUR, FIVE, SIX, SEVEN, EIGHT, NINE};

//    ssd[0] = ZERO;
//    ssd[1] = ZERO;
//    ssd[2] = ZERO;
//    ssd[3] = ZERO;
//    display(ssd);
    init_config();

    while (1) {
        if (wait-- == 0) {
            wait = 100;
            if (count < 9999) {
                count++;
            } else if (count == 9999) {
                count = 0;
            }
        }
        //assume count = 4579 then apply the below logic
        ssd[0] = digit[count / 1000];
        ssd[1] = digit[(count / 100) % 10];
        ssd[2] = digit[(count / 10) % 10];
        ssd[3] = digit[count % 10];

        display(ssd);

    }
    return;
}




