#ifndef TIMER0_H
#define TIMER0_H

void init_timer0(void);

#endif
