# Car-Black-Box

Platform:
	OS – Any Linux distribution, Ubuntu preferred
	xc-8 compiler
	Any standard PIC platform / board


Steps:
1) Goto FIRST RUN CODE folder and run "make" command, then run "make burn" to dump the .hex file into flash memory. (This part of code on PIC is to set default password and events data in EEPROM)

2) Goto SOURCE CODE folder and run "make" coomand, then run "make burn" to dump .hex file into flash memory. 
