/*
 file : cbb.h
 */
#ifndef CBB_H

#define CBB_H
//void display_event(EVENTS event);
void display_menu(const unsigned char* menu_screen[]);
void display_time(void);
void display_view_log(void);
void download_log(void);
void display_uart(void);
void clear_screen(void);
#endif