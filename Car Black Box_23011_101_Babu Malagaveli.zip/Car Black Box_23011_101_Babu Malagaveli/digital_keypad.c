/*------------------------------------------------------------------------------------------------- 
 *   Author         : Babu Malagaveli
 *   Date           : Thu 23.10.2023 16:00:04 IST
 *   File           : digital_keypad.c
 *   Title          : Digital Keypad 
 *   Description    : A digital keypad module providing both level and edge triggering
 *                    functions
 *-----------------------------------------------------------------------------------------------*/

#include "main.h"

void init_digital_keypad(void)
{
    /* Set Keypad Port as input */
    KEYPAD_PORT_DDR = KEYPAD_PORT_DDR | INPUT_LINES;
}

unsigned char read_digital_keypad(unsigned char mode)
{
    static unsigned char once = 1;
    
    if (mode == LEVEL_DETECTION)
    {
        return KEYPAD_PORT & INPUT_LINES;
    }
    else
    {
        if (((KEYPAD_PORT & INPUT_LINES) != ALL_RELEASED) && once)
        {
            once = 0;
            
            return KEYPAD_PORT & INPUT_LINES;
        }
        else if ((KEYPAD_PORT & INPUT_LINES) == ALL_RELEASED)
        {
            once = 1;
        }
    }
    
    return ALL_RELEASED;
}
