/* 
 * File:   main.h
 * Author: Babu Malagaveli
 *
 * Created on 25 Oct, 2023, 8:22 PM
 */
#ifndef MAIN_H
#define MAIN_H

#include "pic_specific.h"
#include "clcd.h"
#include "timer2.h"
#include "ds1307.h"
#include "i2c.h"
#include "ext_eeprom.h"
#include "uart.h"
#include "digital_keypad.h"
#include <string.h>
#include "cbb.h"
#include "adc.h"

#define OFF                                   0
#define PASSWORD_LENGTH                       4
#define MAX_ATTEMPTS                          5
#define BLOCK_TIME_IN_SEC                     30
#define UART_LOG_ENTRIES_COUNT                10
#define PASSWORD_IDLE_TIME                    5
#define CHG_PASSWD_TO_MENU_IN_SEC             15
#define CHANGE_DIS_ON_LONG_PRESS              3

typedef enum {
    CO, //Collision
    ON, //Power ON and flag ON
    GR, //Reverse gear
    GN, //Neutral gear
    G1, //1st gear
    G2, //2nd gear
    G3, //3rd gear
    G4, //4th gear
    ST, //Set Time
    CH, //Change Password
    CL, //Clear Log
    DL //Download Log
} EVENTS;

typedef enum {
    DASHBOARD_SCREEN,
    PASSWORD_SCREEN,
    MENU_SCREEN,
    VIEW_LOG_SCREEN,
    DISP_SET_TIME,
    CHG_PASSWD_SCREEN,
    CLEAR_LOG,
    DOWNLOAD_LOG
} DISPLAY_MODE;

/* Extern unsigned short variables */
extern unsigned short write_addr; // eeprom write address
extern unsigned short read_addr; // eeprom read address
extern unsigned short non_blocking_delay; // Non-blocking delay

/* Extern unsigned char variables */
extern unsigned char clock_reg[3]; // Holds BCD values of Hr-Min-Sec
extern unsigned char time_reg[9]; // Time string holding time values
extern unsigned char org_passwd[PASSWORD_LENGTH + 1]; // Original password storing string
extern unsigned char key_up; // Flag to know up key & down key press
extern unsigned char clock_hand; // Holds sec, min & hr address
extern unsigned char disp_num; // Display number for reading & downloading operation
extern unsigned char scroll; // Flag to detect scroll of eeprom address
extern unsigned char first_index; // First index value of an event
extern unsigned char last_index; // Last index value of an event
extern unsigned char eeprom_log_reg[8]; // Array for storing eeprom read values
extern unsigned char speed; // Vehicle speed

extern unsigned char flag;
extern unsigned char ch;
extern unsigned char i;
extern unsigned char line_1[17];
extern unsigned char line_2[17];

/* Extern display type & the arrow to specific menu */
extern DISPLAY_MODE display;
extern DISPLAY_MODE arrow;


/* Function prototypes */
void get_initial_values_from_eeprom(void);
void write_onto_eeprom(EVENTS store_event);
void read_from_eeprom(void);
void display_time(void);
void set_time(void);
void get_time(void);
void display_event(EVENTS event);
void itoa_display(unsigned char data);
void display_menu(const unsigned char* menu[]);
unsigned char my_strcmp(const unsigned char* str1, const unsigned char* str2);

void display_view_log(void);
void download_log(void);
unsigned char adc(void);


#endif

