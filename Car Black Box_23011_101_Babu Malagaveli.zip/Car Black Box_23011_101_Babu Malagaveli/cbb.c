/*
 file : cbb.c
 */
#include "main.h"

///* Function to display an event */
extern unsigned short delay;
/*switch case to implement the diaplay event on the clcd*/
void display_event(EVENTS event) {
    switch (event) {
        case ON://ON
            if (display == DOWNLOAD_LOG)
                puts("ON");
            else
                clcd_print("ON", LINE2(11));
            break;
        case CO://Collision
            if (display == DOWNLOAD_LOG)
                puts("CO");
            else
                clcd_print("CO", LINE2(11));
            break;
        case GN://Neutral gear
            if (display == DOWNLOAD_LOG)
                puts("GN");
            else
                clcd_print("GN", LINE2(11));
            break;
        case G1://1st gear
            if (display == DOWNLOAD_LOG)
                puts("G1");
            else
                clcd_print("G1", LINE2(11));
            break;
        case G2://2nd gear
            if (display == DOWNLOAD_LOG)
                puts("G2");
            else
                clcd_print("G2", LINE2(11));
            break;
        case G3://3rd gear
            if (display == DOWNLOAD_LOG)
                puts("G3");
            else
                clcd_print("G3", LINE2(11));
            break;
        case G4://4th gear
            if (display == DOWNLOAD_LOG)
                puts("G4");
            else
                clcd_print("G4", LINE2(11));
            break;
        case GR://Reverse gear
            if (display == DOWNLOAD_LOG)
                puts("GR");
            else
                clcd_print("GR", LINE2(11));
            break;
            /* Below events are displayed only in view log & download log */
        case ST://Set time
            if (display == DOWNLOAD_LOG)
                puts("ST");
            else
                clcd_print("ST", LINE2(11));
            break;
        case CH://Change password
            if (display == DOWNLOAD_LOG)
                puts("CH");
            else
                clcd_print("CH", LINE2(11));
            break;
        case CL://Clear log
            if (display == DOWNLOAD_LOG)
                puts("CL");
            else
                clcd_print("CL", LINE2(11));
            break;
        case DL://Download log
            if (display == DOWNLOAD_LOG)
                puts("DL");
            else
                clcd_print("DL", LINE2(11));
    }
}

/* Function to display menu */
void display_menu(const unsigned char* menu[]) {
    if ((key_up && !(arrow % 2)) || ((!key_up) && !(arrow % 2))) {
        clcd_putch(RIGHT_ARROW, LINE1(0));
        clcd_print(menu[arrow], LINE1(2));
        clcd_print(menu[arrow + 1], LINE2(2));
    } else {
        clcd_putch(RIGHT_ARROW, LINE2(0));
        clcd_print(menu[arrow], LINE2(2));
        clcd_print(menu[arrow - 1], LINE1(2));
    }
}

/* Function to display time */
void display_time(void) {
    //Blink the clock hand values
    if (display == DISP_SET_TIME) {
        //SEC_ADDR, MIN_ADDR & HOUR_ADDR happens to be 0, 1 & 2 respectively
        unsigned char i = (clock_hand == SEC_ADDR) ? 10 : (clock_hand == MIN_ADDR) ? 7 : (clock_hand == HOUR_ADDR) ? 4 : 0;
        delay = (delay + 1) % 100;
        (delay < 50) ? clcd_print(time_reg, LINE2(4)) : clcd_print("  ", LINE2(i));
    } else
        clcd_print(time_reg, LINE2(2));
}

/* Function to display view log */
void display_view_log(void) {
    clcd_print("# TIME     E  SP", LINE1(0));
    //disp_num in the range from 0 to UART_LOG_ENTRIES_COUNT - 1
    (disp_num >= first_index) ? clcd_putch('0' + disp_num - first_index, LINE2(0)) : clcd_putch('0' + disp_num + UART_LOG_ENTRIES_COUNT - first_index, LINE2(0));
    //Display time values
    clcd_putch(eeprom_log_reg[0], LINE2(2));
    clcd_putch(eeprom_log_reg[1], LINE2(3));
    clcd_putch(':', LINE2(4));
    clcd_putch(eeprom_log_reg[2], LINE2(5));
    clcd_putch(eeprom_log_reg[3], LINE2(6));
    clcd_putch(':', LINE2(7));
    clcd_putch(eeprom_log_reg[4], LINE2(8));
    clcd_putch(eeprom_log_reg[5], LINE2(9));
    //Display event & speed values
    display_event(eeprom_log_reg[6]);
    itoa_display(eeprom_log_reg[7]);
}

/* Function to download the log */
void download_log(void) {
    //Store view number to adjust the scale from 1 to UART_LOG_ENTRIES_COUNT
    unsigned char view_number;
    //Read each byte from eeprom first index to last index & send to PC via UART
    //Read all values from eeprom and transmit via UART
    disp_num = first_index;
    while ((!scroll && (disp_num <= last_index)) || scroll) {
        read_from_eeprom();
        view_number = (disp_num >= first_index) ? '1' + disp_num - first_index : '1' + disp_num + UART_LOG_ENTRIES_COUNT - first_index;
        if (view_number <= '9') {
            clcd_putch(' ', LINE2(0));
            clcd_putch(view_number, LINE2(0));
        } else
            puts("10");
        puts(".            ");
        //Display time values
        clcd_putch(eeprom_log_reg[0], LINE2(0));
        clcd_putch(eeprom_log_reg[1], LINE2(0));
        clcd_putch(':', LINE2(0));
        clcd_putch(eeprom_log_reg[2], LINE2(0));
        clcd_putch(eeprom_log_reg[3], LINE2(0));
        clcd_putch(':', LINE2(0));
        clcd_putch(eeprom_log_reg[4], LINE2(0));
        clcd_putch(eeprom_log_reg[5], LINE2(0));
        //Display event & speed values
        display_event(eeprom_log_reg[6]);
        itoa_display(eeprom_log_reg[7]);
        disp_num = (disp_num + 1) % UART_LOG_ENTRIES_COUNT;
        if (disp_num == first_index)
            break;
    }
}

/* String compare function which returns 0 if the given strings are equal */
//unsigned char my_strcmp(const char* str1, const char* str2) {

unsigned char my_strcmp(const unsigned char* str1, const unsigned char* str2) {

    //A variable to hold string index
    unsigned char index = 0;
    //Both strings are equal in length
    while (str1[index] != '\0' && str2[index] != '\0') {
        //If characters are not matching, return the ascii difference
        if (str1[index] != str2[index])
            return str1[index] - str2[index];
        //Move to next index
        index++;
    }
    //Return 0 is both strings are equal
    return 0;
}

/* Function to get time */
void get_time(void) {
    clock_reg[0] = read_ds1307(HOUR_ADDR);
    clock_reg[1] = read_ds1307(MIN_ADDR);
    clock_reg[2] = read_ds1307(SEC_ADDR);
    if (clock_reg[0] & 0x40) {
        time_reg[0] = '0' + ((clock_reg[0] >> 4) & 0x01);
        time_reg[1] = '0' + (clock_reg[0] & 0x0F);
    } else {
        time_reg[0] = '0' + ((clock_reg[0] >> 4) & 0x03);
        time_reg[1] = '0' + (clock_reg[0] & 0x0F);
    }
    time_reg[2] = ':';
    time_reg[3] = '0' + ((clock_reg[1] >> 4) & 0x0F);
    time_reg[4] = '0' + (clock_reg[1] & 0x0F);
    time_reg[5] = ':';
    time_reg[6] = '0' + ((clock_reg[2] >> 4) & 0x0F);
    time_reg[7] = '0' + (clock_reg[2] & 0x0F);
    time_reg[8] = '\0';
}

void set_time(void) {
    if ((++clock_reg[HOUR_ADDR - clock_hand] > 9) && ((clock_reg[HOUR_ADDR - clock_hand] - 10) % 0x10 == 0))
        clock_reg[HOUR_ADDR - clock_hand] += 6;
    //Increment selected field value
    switch (clock_hand) {
        case SEC_ADDR://Change sec field
        case MIN_ADDR://Change min field
            if (clock_reg[HOUR_ADDR - clock_hand] == 0x60)
                clock_reg[HOUR_ADDR - clock_hand] = 0;
            break;
        case HOUR_ADDR://Change hr field
            if (clock_reg[0] == 0x24)
                clock_reg[0] = 0;
            break;
    }
    //Note that SEC_ADDR, MIN_ADDR & HOUR_ADDR are 0, 1 & 2 respectively. So we will use the same as index values in time string
    for (unsigned char i = SEC_ADDR; i <= HOUR_ADDR; i++)
        write_ds1307(i, clock_reg[HOUR_ADDR - i]);
    /* Clearing the CH bit of the RTC to Start the Clock */
    write_ds1307(SEC_ADDR, read_ds1307(SEC_ADDR) | 0x7F);
}

void itoa_display(unsigned char data) {
    unsigned char array[3];
    array[0] = '0' + data / 10;
    array[1] = '0' + data % 10;
    array[2] = '\0'; //Terminate the string
    if (display == DOWNLOAD_LOG) {
        puts("            ");
        puts(array);
    } else
        clcd_print(array, LINE2(14));
}

void display_uart(void) {
    ch = getchar();
    putchar(ch); // Transmit the received character back to the laptop.

    if ((i < 16) && (flag == 1)) {
        // Display the character on LINE-1 of the CLCD at position 'i'.
        clcd_putch(ch, LINE1(i));
        i += 1; // Increment the index for the next character on LINE-1.

        if (i == 16) {
            i = 0; // Reset the index when LINE-1 is full.
            flag = 2; // Switch to LINE-2 for the next character.
        }
    } else if ((i < 16) && (flag == 2)) {
        line_1[i] = ch; // Store the character in LINE-2 in 'line_1'.
        clcd_putch(ch, LINE2(i)); // Display the character on LINE-2 at position 'i'.
        i += 1; // Increment the index for the next character on LINE-2.

        if (i == 16) {
            i = 0; // Reset the index when LINE-2 is full.
            clcd_print(line_1, LINE1(0)); // Shift characters from LINE-2 to LINE-1.
            clcd_print(line_2, LINE2(0)); // Clear LINE-2 for the next character.
        }
    }
}
void clear_screen() {
    clcd_write(CLEAR_DISP_SCREEN, INST_MODE); //0x01 1
    __delay_us(100); //100 usec 
}
