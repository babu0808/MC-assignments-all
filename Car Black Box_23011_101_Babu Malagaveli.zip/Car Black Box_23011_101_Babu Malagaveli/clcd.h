/* 
 * File:   clcd.h
 * Author: Babu Malagaveli
 *
 * Created on 25 Oct, 2023, 8:22 PM
 */
#ifndef CLCD_H
#define	CLCD_H

#define _XTAL_FREQ                  20000000

#define CLCD_DATA_PORT_DDR          TRISD
#define CLCD_RS_DDR                 TRISE2
#define CLCD_EN_DDR                 TRISE1

#define CLCD_DATA_PORT              PORTD
#define INPUT						0xFF
#define OUTPUT                      0x00
#define INST_MODE                   0
#define DATA_MODE                   1

#define LEFT_ARROW										0x7F // 0x1B?
#define RIGHT_ARROW										0x7E // 0x1A?

#define HI                          1
#define LOW                         0

#define LINE1(x)                    (0x80 + x)
#define LINE2(x)                    (0xC0 + x)

#define EIGHT_BIT_MODE              0x33
#define FOUR_BIT_MODE               0x02
#define TWO_LINES_5x8_4_BIT_MODE    0x28
#define TWO_LINE_5x7_MATRIX_8_BIT						clcd_write(0x38, INST_MODE)

#define CLEAR_DISP_SCREEN           0x01
#define DISP_ON_AND_CURSOR_OFF      0x0C
#define DISP_ON_AND_CURSOR_ON       0x0B
#define MOV_CURSOR_ADDR(address)						clcd_write(address, INST_MODE)
#define DISP_ON_AND_CURSOR_BILNK_ON						clcd_write(0x0F, INST_MODE)
#define CURSOR_HOME										clcd_write(0x02, INST_MODE)

void init_clcd(void);
void clcd_putch(const char data, unsigned char addr);
void clcd_write(unsigned char byte, unsigned char mode);
void clcd_print(const char *str, unsigned char addr);

#endif	/* CLCD_H */
