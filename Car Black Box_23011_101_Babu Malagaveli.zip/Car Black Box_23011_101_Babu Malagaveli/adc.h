/* 
 * File:   cbb.h
 * Author: Babu Malagaveli
 *
 * Created on 25 Oct, 2023, 8:22 PM
 */
#ifndef ADC_H
#define	ADC_H

void init_adc(void);
unsigned short read_adc(void);

#endif	/* ADC_H */

