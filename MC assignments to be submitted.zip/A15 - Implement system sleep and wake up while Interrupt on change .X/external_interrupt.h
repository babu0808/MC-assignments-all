/* 
 * File:   external_interrupt.h
 * Author: CFT
 *
 * Created on 22 April, 2020, 10:49 PM
 */

#ifndef EXTERNAL_INTERRUPT_H
#define	EXTERNAL_INTERRUPT_H

void init_ext_int(void);

#endif	/* EXTERNAL_INTERRUPT_H */

