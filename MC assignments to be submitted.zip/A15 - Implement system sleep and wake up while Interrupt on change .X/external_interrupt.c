/*------------------------------------------------------------------------------------------------- 			    
 *   Author         : Babu Malagaveli
 *   Date           : 20.10.2023 16:00:04 IST
 *   File           : external_interrupt.c
 *   Title          : External Interrupt Configuration
 *   Description    : A configuration function to detect rising edge signal
 *-----------------------------------------------------------------------------------------------*/

#include <xc.h>
#include "main.h"

void init_ext_int(void) {
    /* Selecting Falling Edge Trigger */
    INTEDG = 0;
    /* Enable the External Interrupt */
    INTE = 1;
}
