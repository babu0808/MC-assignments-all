#ifndef MAIN_H
#define MAIN_H


#include <xc.h>
#include "ssd.h"
#include "digital_keypad.h"
#include "ext_eeprom.h"
#include "i2c.h"


#endif