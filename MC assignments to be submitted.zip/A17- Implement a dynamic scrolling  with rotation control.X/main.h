#ifndef MAIN_H 
#define MAIN_H

#include <xc.h>
#include "matrix_keypad.h"
#include "clcd.h"
#include <string.h>

void add_count_to_msg(int count);
#endif