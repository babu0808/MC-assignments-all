#ifndef TIMERS_H
#define	TIMERS_H

//void init_timer0(void);
void init_timer2(void);
void software_pwm(void);

#endif	/* TIMERS_H */

