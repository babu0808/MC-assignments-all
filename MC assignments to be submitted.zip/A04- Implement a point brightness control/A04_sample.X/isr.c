#include <xc.h>
#include "main.h"
#include "timers.h"

extern unsigned int duty_cycle;
unsigned int req_time = 0;
extern unsigned int loop_counter;
extern unsigned int flag;

void __interrupt() isr(void) {
    static unsigned int count = 0;
    if (loop_counter++ < duty_cycle) //If the Program cycle value is less than the Duty Cycle, the LED shall be ON (High state of the Waveform).
    {
        LED1 = ON;
    } else //If the Program cycle value is greater than the Duty Cycle and less than PERIOD, the LED shall be OFF (Low state of the Waveform).
    {
        LED1 = OFF;
    }

    if (loop_counter >= PERIOD) //If the Program Cycle becomes greater than PERIOD, reset it to 0.
    {
        loop_counter = 0;
    }
    if (TMR2IF == 1) //If the Timer2 Overflow Interrupt Flag Bit is set, Timer2 is requesting for an Interrupt.
    {
        TMR2 = TMR2 + 2;
        if (count++ == 20000) //The formula for the Timer2 yields the result as: 1 count for every 20000 ticks.
        {
            if (req_time++ == 5) //If 5 count have elapsed, set the 'flag' as 1.
            {
                req_time = 0;
                flag = 1;
            }
            count = 0; //Reset the 'count_3' to 0 for the next cycle.
        }
        TMR2IF = 0; //To clear the Timer2 Overflow Interrupt Flag Bit to avoid Recursive interrupts.
    }
    //    TMR2IF = 0; //To clear the Timer2 Overflow Interrupt Flag Bit to avoid Recursive interrupts.

}
