#include <xc.h>
#include "main.h"
#include "digital_keypad.h"
#include "timers.h"

unsigned int flag;
unsigned int loop_counter;
unsigned int duty_cycle = 50;

static void init_config(void) {
    /* Basic Configuration for all the PORTS and other Peripherals */
    ADCON1 = 0x0F;
    LED_ARRAY1 = 0x00;
    LED_ARRAY1_DDR = 0x00;
    init_digital_keypad();
    init_timer2();
    GIE = 1;
    PEIE = 1;
}

void main(void) {
    unsigned char key;
    //    unsigned int loop_counter;
    //    unsigned int duty_cycle = 50;

    init_config();

    while (1) {
        /* Reading SW from Digital Keypad */
        key = read_digital_keypad(STATE);

        if (flag >= 1 || key == SW1) {
            if (key == SW1) //If the SW1 is pressed, then make the Duty Cycle as 100 percent.
            {
                duty_cycle = PERIOD; //100
            } else {
                duty_cycle = 10; //Otherwise, make the Duty Cycle as 10 percent.
            }
            flag = 0;
        }

        //        if (loop_counter++ < duty_cycle) //If the Program cycle value is less than the Duty Cycle, the LED shall be ON (High state of the Waveform).
        //        {
        //            LED1 = ON;
        //        } else //If the Program cycle value is greater than the Duty Cycle and less than PERIOD, the LED shall be OFF (Low state of the Waveform).
        //        {
        //            LED1 = OFF;
        //        }
        //
        //        if (loop_counter >= PERIOD) //If the Program Cycle becomes greater than PERIOD, reset it to 0.
        //        {
        //            loop_counter = 0;
        //        }
    }
}
