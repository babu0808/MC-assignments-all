/* 
 * File:   pattern1.c
 * Author: Babu Malagaveli
 *
 * Created on September 30, 2023, 4:12 PM
 */
#include <xc.h>
#include "main.h"

extern unsigned char led_pos,n;    // extern declaration reference to led_pos and wait with the same name defined in another source file
extern unsigned int wait;

 void led_train (void)
{   
	if (wait++ == 10000)								//To implement the Non-Blocking Delay.
	{
		if (led_pos <= 8)									//The direction is set from Left to Right to glow the first 8 leds.
		{
            LED_ARRAY1 =  (unsigned char)((LED_ARRAY1 << 1) | 1);       //The LEDs will be turned ON one by one starting from the LSB side.
		}
		else if (led_pos <= 16)								//The direction is set from Left to Right.
		{
			LED_ARRAY1 =  (unsigned char)(LED_ARRAY1 << 1);					//The LEDs will be turned OFF one by one starting from the LSB side.
		}
		else if (led_pos <= 24)								//The direction is set from Right to Left.
		{
			LED_ARRAY1 =  (unsigned char)(LED_ARRAY1 | (1 << (n - 1)));	//The LEDs will be turned ON one by one starting from the MSB side.
		}
		else if (led_pos <= 32)								//The direction is set from Right to Left.
		{
			LED_ARRAY1 = LED_ARRAY1 >> 1;					//The LEDs will be turned OFF one by one starting from the MSB side.
		}
		
		wait = 0;						//Update the Delay Timer back to '1' for the next iteration.
		led_pos += 1;
		
		if (led_pos == 17)					//If the LEDs have been turned ON and OFF in Left to Right manner, make the LED states back to default.
			LED_ARRAY1 = 0;
		
		if (led_pos > 17 && led_pos <= 25)		//If the Direction is changed to Right to Left.
		{
			n -= 1;					//The 'n' shall be updated for turning on the LEDs one by one.
			if (n < 1)				//If the 'n' becomes less than '1'; it shall be restored to it's default value.
				n = 8;
		}
		if (led_pos > 32)					//If the 'led_pos' becomes more than '32'; it shall be restored to it's default value.
			led_pos = 1;
	}
}