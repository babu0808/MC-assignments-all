/*
 * File:   main.c
 * Author: Babu Malagaveli
 * Date : 30.09.2023
 * Problem Statement : Write a Embedded C program to display the multiple patterns on the LEDs controlled by the switches.
 *                     For every switch, dedicate a LEDs glow pattern.The pattern should change on key press
 * Description :
 *  1.	Upon giving the power supply, all 8 LEDs should be OFF.
    2.	Now, press switch-1 on the Digital Keypad, LEDs should glow according to the pattern-1*
    3.	Press switch-2, LEDs should glow according to the pattern-2*
    4.	Press switch-3, LEDs should glow according to the pattern-3*
    5.	Press switch-4, LEDs should glow according to the pattern-4*
    *pattern-1: The LEDs should glow from Left to Right and Right to left as explained in the assignment-1.
    *pattern-2: The LEDs should glow from left to Right and switch off from left to right, no direction control/ direction change.
    *pattern-3: The LEDs should blink alternately.
    *pattern-4: The LEDs has to blink nibble wise, i.e first 4 LEDs will be ON, next 4 LEDs will be OFF, after first 4 LEDs will be OFF, next 4 LEDs will be ON.

 */

#include <xc.h>
#include "main.h"
#include "digital_keypad.h"

unsigned char led_pos = 1;  // To store the Direction of the Activity.
unsigned int wait = 0;  // To store the Delay Timer.
unsigned char n = 8; // To store the Position of LED for the direction of Right to Left.

#pragma config WDTE = OFF

static void init_config(void)
{
       LED_ARRAY1 = OFF;                   /*To keep all LEDS OFF initially*/
  
       LED_ARRAY1_DDR = 0x00;             /*To configure PORTD as output PORT*/

       init_digital_keypad();             /* Initializing digital keypad */
}

void main(void)
{
    unsigned char key, key_copy;            // Variable declaration

    init_config();                          //function call for LED configuration

    while (1)
    {
        key = read_digital_keypad(LEVEL);    /*To read key press*/
                
        if (key != ALL_RELEASED)             /*If switch is pressed, then only update key_copy*/
        {   
             if(key_copy != key)            /*if a different key is pressed,reset and perform that key operation*/
            {
                LED_ARRAY1 = OFF;
            }
            key_copy = key;               /*take a copy of the key pressed to perform the pattern even on switch release*/
        }
        glow_on_press(key_copy);
        
    }
    return;
}

void glow_on_press(unsigned char key)    //passing key_copy as an argument
{       
    if (key == SW1)
    {   
        led_train();        
        // Code for pattern1 
        // The LEDs should glow from Left to Right and Right to left as explained in the assignment-1.
    }
    else if (key == SW2)
    {
        led_Left_to_Right();
        // Code for pattern2
      // The LEDs should glow from left to Right and switch off from left to right, no direction control/ direction change
    } 
    else if (key == SW3)
    {
        led_alternate();
        // Code for pattern3
      // The LEDs should glow alternatively
    }
    else if (key == SW4)
    {
        led_nibble();
        // Code for pattern4
        // The LEDs has to blink nibble wise, i.e first 4 LEDs will be ON, next 4 LEDs will be OFF,
        // after first 4 LEDs will be OFF, next 4 LEDs will be ON.
                
    }
}
