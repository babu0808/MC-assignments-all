/* 
 * File:   pattern2.c
 * Author: Babu Malagaveli
 *
 * Created on September 30, 2023, 4:12 PM
 */
#include <xc.h>
#include "main.h"

extern unsigned char led_pos, n;    // reference to led_pos and wait with the same name defined in another source file
extern unsigned int wait;

void led_Left_to_Right (void)
{
	if (wait++ == 10000)								//To implement the Non-Blocking Delay.
	{
		if (led_pos <= 8)									//The direction is set from Left to Right.
		{
			LED_ARRAY1 =  (unsigned char)(1 << led_pos) - 1;  //The LEDs will be turned ON one by one starting from the LSB side.
		}
		else if (led_pos <= 16)								//The direction is set from Left to Right.
		{
			LED_ARRAY1 =  (unsigned char)(LED_ARRAY1 << 1);					//The LEDs will be turned OFF one by one starting from the LSB side.
		}

		wait = 0;                                           //reset the wait to 0 after every 500000 cycles so that the change in LEDS is visible
		led_pos += 1;

		if (led_pos > 16)									//If the LEDs have been turned ON and OFF completely, the led_position shall again start from 1.
			led_pos = 1;
	}
}
