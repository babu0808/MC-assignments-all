#include <stdio.h>

int is_xdigit(char); // function prototype

int main()
{
    char ch;
    short ret;

    printf("Enter a character: ");
    scanf("%c", &ch); // reading the character from the user

    ret = is_xdigit(ch); // function call

    if (ret == 1)
    {
        printf("Entered character is an hexadecimal digit");
    }
    else
    {
        printf("Entered character is not an hexadecimal digit");
    }

    return 0;
}
int is_xdigit(char ch) // function definition
{
    int ret;
    if ((ch >= '0' && ch <= '9') || (ch >= 'a' && ch <= 'f') || (ch >= 'A' && ch <= 'F'))
    {
        ret = 1;
    }
    else
    {
        ret = 0;
    }
    return ret;
}
