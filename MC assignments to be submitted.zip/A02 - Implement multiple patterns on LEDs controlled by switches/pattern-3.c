/* 
 * File:   pattern3.c
 * Author: Babu Malagaveli
 *
 * Created on September 30, 2023, 4:12 PM
 */
#include <xc.h>
#include "main.h"

extern unsigned char led_pos;       // reference to led_pos and wait with the same name defined in another source file
extern unsigned int wait;

void led_alternate(void)
{
	if (wait++ == 20000)			//To implement the Non-Blocking Delay.
	{
		if (led_pos == 1)				//The LED pattern shall be: 10101010.
		{
			LED_ARRAY1 = 0xAA;          // turn on the alternative LEDs
		}
		else						//The LED pattern shall be: 01010101.
		{
			LED_ARRAY1 = 0x55;      //0101 0101 
		}
		wait = 0;
		led_pos += 1;
		if (led_pos > 2)				//If one set of Alternate Blinking is executed, the led_positions are reset.
			led_pos = 1;
	}
}
