/* 
 * File:   pattern4.c
 * Author: Babu Malagaveli
 *
 * Created on September 30, 2023, 4:12 PM
 */
#include <xc.h>
#include "main.h"

extern unsigned char led_pos;   // 1 reference to led_pos and wait with the same name defined in another source file
extern unsigned int wait;       //0

void led_nibble (void)
{
	if (wait++ == 20000)			//To implement the Non-Blocking Delay.
	{
		if (led_pos == 1)				//The LED pattern shall be: 00001111., initially it is 1 from main.c 
		{
			LED_ARRAY1 = 0x0F;          //turn ON the last 4 LEDs
		}
		else						//The LED pattern shall be: 11110000.
		{
			LED_ARRAY1 = 0XF0;      //turn ON the first 4 LEDs
		}

		wait = 0;                   //reset the wait to 0 
		led_pos += 1;                       
		if (led_pos > 2)			//reset the LED position once every Nibble turned ON and OFF
			led_pos = 1;
	}
}
