/* 
 * File:   main.h
 * Author: Babu Malagaveli
 *
 * Created on September 30, 2023, 4:12 PM
 */

#ifndef MAIN_H
#define	MAIN_H

#define OFF              0x00

#define  LED_ARRAY1      PORTD
#define  LED_ARRAY1_DDR  TRISD
void glow_on_press(unsigned char key);
#endif	/* MAIN_H */

/* Function calls for the Patterns */
unsigned char key_press(void);
void led_train(void);
void led_Left_to_Right(void);
void led_alternate(void);
void led_nibble(void);