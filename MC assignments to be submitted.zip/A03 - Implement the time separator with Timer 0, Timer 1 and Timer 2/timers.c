/*
Name         : Babu Malagaveli
Date         : 28 Sep 2023
Description  : To perform the operations when an Interrupt is requested.
*/
#include <xc.h>
#include "timers.h"

void init_timer0(void)
{   
    T0CS = 0;			//To set the Instruction Cycle Clock (Fosc/4) as the Clock source of Timer0.
	PSA = 1;            /* Assinging the prescaler to Watchdog Timer */
    TMR0 = 6;			//To set the Timer0 register value from '6'. The calculation will set the Frequency required.
	TMR0IE = 1;			//To set the Timer0 Overflow Interrupt Enable
}
 
void init_timer1(void)
{
	TMR1 = 3036;		//To set the Timer1 register value from '3036'. The calculation will set the Frequency required.
    TMR1ON = 1;         //enable the TIMER1
    TMR1IE = 1;         //int enable bit for timer1
}
void init_timer2(void)
{
	PR2 = 250;			//To set the Timer2 Period register value as '250' for the Overflow to happen after that particular count.
    TMR2ON = 1;			//To enable the Timer2.
    TMR2IE = 1;			//To set the Timer2 Overflow Interrupt Enable Bit.
}
