/*
Name         : Babu Malagaveli
Date         : 28 Sep 2023
Description  : header file to declare macros 
*/

#include <xc.h> // include processor files - each processor file is guarded.  
#ifndef MAIN_H  // This is a guard condition so that contents of this file are not included
                // more than once.  
#define MAIN_H

/* Macro for the PORTS */
#define LED_PORTD_DDR TRISD
#define LED_ARRAY PORTD

#define LED0 RD0
#define LED1 RD1
#define LED2 RD2


#endif
