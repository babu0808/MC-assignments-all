/*
  File:   main.c
  Author: Babu Malagaveli
  Date: September 28, 2023, 4:25 PM
  Description  : Implement the Time Separator with Timer 0, Timer 1 and Timer 2. The system should generate the time separator (half-second blink) of the Digital Clock with Multiple timers.
    1. All three LEDs assigned to specific Timer should toggle at frequency of 0.5 Hz (500 msecs) as soon as the board is powered ON or Reset.
    2. There should be Time synchronization between all LEDs on longer runs greater than hours (No drifts in the output should be seen).
*/
#include <xc.h>
#include "main.h"
#include "timers.h"
#pragma config WDTE = OFF //Watchdog timer disabled


static void init_config (void)
{   
    LED_PORTD_DDR = 0x00;   //To make the PORTD as an Output port.
    LED_ARRAY = 0x00;       //To turn OFF the LEDs when the Power is ON.
    
    init_timer0();
    TMR0IF = 0;			//To clear the Timer0 Overflow Interrupt Flag Bit.
    
    init_timer1();
    TMR1IF = 0;         //To clear the Timer2 Overflow Interrupt Flag Bit.}

    init_timer2();
	TMR2IF = 0;			//To clear the Timer2 Overflow Interrupt Flag Bit.
    
    GIE = 1;
    PEIE = 1;           //peripheral int enable bit 
    
}


void main()
{
	init_config();		//To initialize the ports and registers with the default values.

	while (1)
	{
	;					//Empty Infinite loop.
	}
}
