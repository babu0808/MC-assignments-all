/*
Name         : Babu Malagaveli
Date         : 28 Sep 2023
Description  : To perform the operations when an Interrupt is requested.
*/
#ifndef TIMERS_H
#define	TIMERS_H

void init_timer0(void);
void init_timer1(void);
void init_timer2(void);

#endif	/* TIMERS_H */

