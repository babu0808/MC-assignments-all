/*
 * File :   A01-Implement LED train pattern on LEDS
 * Name :   Babu Malagaveli
 * Date :   30.09.2023
 *Description  : Implement LED train pattern on LEDs.
1. Consider 8 LEDs from the Board, these LEDs has to glow one by one as if a train is coming out of a tunnel every second (approximately without timer implementation) from Left to Right 
2. The above pattern shall be executed as soon as the board is powered on or reset (Lets call it as exit).
3. Once all LEDs are ON, the LEDs should switch OFF one by one as if the train is entering inside a tunnel from Left to Right (Lets call it as entry).
4. Once the exit and entry is complete , change the direction of the train from Right to Left.
5. This process of changing direction has to be repeated between every exit and entry of the train.
 */

#include <xc.h>
#include "main.h"

#pragma config WDTE = OFF // Watchdog Timer Enable bit (WDT disabled)

/* Function: init_config()
 * Description: This function is used to setup initial peripheral
 * configuration, like setting port directions, initializing port values
 */
static void init_config(void)
{
    LED_ARRAY1_DDR = 0x00; // Set direction to o/p
    LED_ARRAY1 = 0x00;     // Set initial port value to 0
}

void main(void)
{
    unsigned int WAIT = 50000;                      //declared the wait time as 50000 
    unsigned char LED_POS = 0;                      //initial position of LED = 0
    unsigned char n = 8;                            //let the n be 8
    init_config();                                  //function call to initialize led configuration

    while (1)
    {
        // LEFT to RIGHT ON/OFF
        if (WAIT-- == 0)
        {
            if (LED_POS < 8)                            //operate on LEDs 8 times from left to right
            {
                LED_ARRAY1 = (LED_ARRAY1 << 1) | 1;     //Turn ON LEDs from RD0 - RD7 00000001 00000011 00000111 00001111 ....
            }
            else if (LED_POS < 16)                      
            {
                LED_ARRAY1 = LED_ARRAY1 << 1;           //Turn off the LEDs from RD0 to RD7 01111111 00111111 00011111 00001111 ....
            } 
            // Right to left ON/OFF
            else if (LED_POS < 24)                      //operate on LEDs 8 times from right to left
            {
                LED_ARRAY1 = LED_ARRAY1 | (1 << (n - 1));   //turn on the LEDs from right to left
            }
            else if (LED_POS < 32)                          //operate on LEDs from right to left
            {
                LED_ARRAY1 = (LED_ARRAY1 >> 1);             //turn off LEDs from right to left
            }
            else                                        
            {   
                if(LED_POS >= 32)                           //if the operation goes beyond 32 make it to start from 0 again
                {
                    LED_POS = 0; 
                }
            }
            WAIT = 50000;                                   //everytime the delay completes, set WAIT to 50000 again 
            LED_POS++;                                      //increment the LED position

            if (LED_POS == 16)                              //if the one pattern operation completes, set the LED to OFF 
            {
                LED_ARRAY1 = 0;
            }
            else if (LED_POS > 16 && LED_POS < 25)      //If the Direction is changed to Right to Left.
            {
                n -= 1;                                 //The n shall be updated for turning on the LEDs one by one.
                if (n < 1)                              //if the n value becomes less than 1,then make it to default
                {
                    n = 8;
                }
            }
        }
    }
    return;
}
